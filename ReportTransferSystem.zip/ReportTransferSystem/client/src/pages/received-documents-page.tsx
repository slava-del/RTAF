import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Order, Document } from "@shared/schema";
import { formatDate, getStatusColor } from "@/lib/utils";
import { Icon } from "@/components/ui/icons";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";

export default function ReceivedDocumentsPage() {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  
  // Fetch completed orders
  const { 
    data: orders = [], 
    isLoading: isOrdersLoading 
  } = useQuery<Order[], Error>({
    queryKey: ["/api/orders"],
    select: (orders) => orders.filter(order => order.status === "completed"),
  });
  
  // Fetch uploaded documents
  const { 
    data: documents = [], 
    isLoading: isDocumentsLoading 
  } = useQuery<Document[], Error>({
    queryKey: ["/api/documents"],
  });
  
  const handlePreviewDocument = (order: Order) => {
    setSelectedOrder(order);
    setPreviewDialogOpen(true);
  };
  
  const handleDownload = async (documentId: number) => {
    try {
      window.open(`/api/documents/${documentId}/download`, '_blank');
    } catch (error) {
      console.error("Download failed:", error);
    }
  };
  
  const orderColumns = [
    {
      header: "Document Name",
      accessorKey: "orderId",
      cell: (row: Order) => (
        <div className="flex items-center space-x-2">
          <Icon 
            name={row.documentType === "xlsx" ? "file-spreadsheet" : "file-text"} 
            className={`h-5 w-5 ${
              row.documentType === "xlsx" ? "text-green-600" : "text-blue-600"
            }`} 
          />
          <span className="font-medium text-primary">Report {row.orderId}</span>
        </div>
      ),
    },
    {
      header: "Date Received",
      accessorKey: "updatedAt",
      cell: (row: Order) => formatDate(row.updatedAt || row.createdAt),
    },
    {
      header: "Status",
      accessorKey: "status",
      cell: (row: Order) => {
        const { bg, text } = getStatusColor(row.status);
        return (
          <Badge variant="outline" className={`${bg} ${text}`}>
            {row.status}
          </Badge>
        );
      },
    },
    {
      header: "Type",
      accessorKey: "documentType",
      cell: (row: Order) => row.documentType.toUpperCase(),
    },
    {
      header: "Actions",
      accessorKey: "id",
      cell: (row: Order) => (
        <div className="flex space-x-2 justify-end">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => handlePreviewDocument(row)}
          >
            <Icon name="eye" className="mr-1 h-4 w-4" />
            View
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => {
              // In a real app, this would download the specific document
              // For now, just show an alert
              alert(`Downloading ${row.orderId}`);
            }}
          >
            <Icon name="download" className="mr-1 h-4 w-4" />
            Download
          </Button>
        </div>
      ),
    },
  ];
  
  const documentColumns = [
    {
      header: "Document Name",
      accessorKey: "name",
      cell: (row: Document) => (
        <div className="flex items-center space-x-2">
          <Icon 
            name={row.type === "xlsx" ? "file-spreadsheet" : "file-text"} 
            className={`h-5 w-5 ${
              row.type === "xlsx" ? "text-green-600" : "text-blue-600"
            }`} 
          />
          <span className="font-medium text-primary">{row.name}</span>
        </div>
      ),
    },
    {
      header: "Date Uploaded",
      accessorKey: "uploadedAt",
      cell: (row: Document) => formatDate(row.uploadedAt),
    },
    {
      header: "Size",
      accessorKey: "size",
      cell: (row: Document) => {
        const sizeMB = (row.size / (1024 * 1024)).toFixed(2);
        return `${sizeMB} MB`;
      },
    },
    {
      header: "Type",
      accessorKey: "type",
      cell: (row: Document) => row.type.toUpperCase(),
    },
    {
      header: "Actions",
      accessorKey: "id",
      cell: (row: Document) => (
        <div className="flex space-x-2 justify-end">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => {
              // View document, in real app would show a preview
              alert(`Viewing ${row.name}`);
            }}
          >
            <Icon name="eye" className="mr-1 h-4 w-4" />
            View
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => handleDownload(row.id)}
          >
            <Icon name="download" className="mr-1 h-4 w-4" />
            Download
          </Button>
        </div>
      ),
    },
  ];

  return (
    <MainLayout
      breadcrumbItems={[{ label: "Received Documents" }]}
      title="Received Documents"
      description="View and download your processed documents and reports."
    >
      <Card className="mb-6">
        <CardHeader className="pb-3">
          <Tabs defaultValue="received">
            <div className="flex justify-between items-center">
              <TabsList>
                <TabsTrigger value="received">Received Reports</TabsTrigger>
                <TabsTrigger value="uploaded">Uploaded Documents</TabsTrigger>
              </TabsList>
              
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Icon name="search" className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input className="pl-10" placeholder="Search documents..." />
                </div>
                <Button variant="outline" size="sm">
                  <Icon name="filter" className="mr-1 h-4 w-4" />
                  Filter
                </Button>
              </div>
            </div>
            
            <TabsContent value="received" className="pt-4">
              {isOrdersLoading ? (
                <div className="space-y-3">
                  {Array(5).fill(0).map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : orders.length === 0 ? (
                <div className="text-center py-12 text-gray-500 border-2 border-dashed border-gray-200 rounded-md">
                  <Icon name="inbox" className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium mb-2">No received documents</h3>
                  <p>Once your orders are processed, your reports will appear here.</p>
                  <Button className="mt-4" onClick={() => window.location.href = "/"}>
                    Create New Order
                  </Button>
                </div>
              ) : (
                <DataTable
                  data={orders}
                  columns={orderColumns}
                  searchField="orderId"
                />
              )}
            </TabsContent>
            
            <TabsContent value="uploaded" className="pt-4">
              {isDocumentsLoading ? (
                <div className="space-y-3">
                  {Array(5).fill(0).map((_, i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : documents.length === 0 ? (
                <div className="text-center py-12 text-gray-500 border-2 border-dashed border-gray-200 rounded-md">
                  <Icon name="file-plus" className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <h3 className="text-lg font-medium mb-2">No uploaded documents</h3>
                  <p>You haven't uploaded any documents yet.</p>
                  <Button className="mt-4" onClick={() => window.location.href = "/form-submission"}>
                    Upload Document
                  </Button>
                </div>
              ) : (
                <DataTable
                  data={documents}
                  columns={documentColumns}
                  searchField="name"
                />
              )}
            </TabsContent>
          </Tabs>
        </CardHeader>
      </Card>
      
      {/* Document Preview Dialog */}
      <Dialog open={previewDialogOpen} onOpenChange={setPreviewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Document Preview</DialogTitle>
            <DialogDescription>
              Preview of report {selectedOrder?.orderId}
            </DialogDescription>
          </DialogHeader>
          
          <div className="border-2 rounded-md p-8 h-96 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <Icon 
                name={selectedOrder?.documentType === "xlsx" ? "file-spreadsheet" : "file-text"} 
                className={`h-16 w-16 mx-auto mb-4 ${
                  selectedOrder?.documentType === "xlsx" ? "text-green-600" : "text-blue-600"
                }`} 
              />
              <h3 className="text-lg font-medium mb-2">Report Preview</h3>
              <p className="text-gray-500 mb-4">
                Preview is not available for this document type. Please download the file to view its contents.
              </p>
              <Button>
                <Icon name="download" className="mr-2 h-4 w-4" />
                Download to View
              </Button>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreviewDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
